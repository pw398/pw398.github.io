This site is based on the template made by samasault: https://github.com/samarsault/plainwhite-jekyll
